/**
 * 
 * @author Alex Runs GUI
 */
public class TEMP_Driver {
	/**
	 * Makes instance of TEMP_GUI
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		TEMP_GUI gui = new TEMP_GUI();
		gui.initGUI();
	}

}
