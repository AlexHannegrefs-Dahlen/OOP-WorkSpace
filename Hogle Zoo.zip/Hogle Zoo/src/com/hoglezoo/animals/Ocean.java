package com.hoglezoo.animals;

import java.util.Random;

/**
 * 
 * @author Alex
 *
 */
public class Ocean {
	private String name;
	private boolean waterBreathing;
	private ModesOfTravel travelMode;
	private String speak;

	public Ocean() {

	}

	public Ocean(String name, boolean waterBreathing, ModesOfTravel travelMode, String speak) {
		this.setName(name);
		this.setWaterBreathing(waterBreathing);
		this.setTravelMode(travelMode);
		this.setSpeak(speak);
	}

	/**
	 * 
	 */
	public boolean equals(Object obj) {
		Ocean equal = (Ocean) obj;
		return (this.isWaterBreathing() == equal.isWaterBreathing() && this.getTravelMode() == equal.getTravelMode()
				&& this.getSpeak() == equal.getSpeak());
	}

	private int numberGen() {
		Random gen = new Random();
		return gen.nextInt(2);
	}

	/**
	 * 
	 * @param Jungle
	 *            object to fight Ocean
	 */
	public void fight(Jungle fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Arctic
	 *            object to fight Ocean
	 */
	public void fight(Arctic fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Safari
	 *            object to fight Ocean
	 */
	public void fight(Safari fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Ocean
	 *            object to fight Ocean
	 */
	public void fight(Ocean fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Name cannot be null");
		}
		this.name = name;
	}

	/**
	 * @return the speak
	 */
	public String getSpeak() {
		return speak;
	}

	/**
	 * @param speak
	 *            the speak to set
	 */
	public void setSpeak(String speak) {
		if (speak == null)
			throw new IllegalArgumentException("Speak cannot be null");
		this.speak = speak;
	}

	/**
	 * @return the waterBreathing
	 */
	public boolean isWaterBreathing() {
		return waterBreathing;
	}

	/**
	 * @param waterBreathing
	 *            the waterBreathing to set
	 */
	public void setWaterBreathing(boolean waterBreathing) {
		this.waterBreathing = waterBreathing;
	}

	/**
	 * @return the travelMode
	 */
	public ModesOfTravel getTravelMode() {
		return travelMode;
	}

	/**
	 * @param travelMode
	 *            the travelMode to set
	 */
	public void setTravelMode(ModesOfTravel travelMode) {
		this.travelMode = travelMode;
	}
}
