package com.hoglezoo.animals;

/**
 * 
 * @author Alex
 *
 */
public enum ModesOfTravel {
	Fins,
	Propulsion,
	WaveRiding
}
