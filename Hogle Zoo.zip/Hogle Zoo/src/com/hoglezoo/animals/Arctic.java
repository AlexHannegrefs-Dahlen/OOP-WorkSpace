package com.hoglezoo.animals;

import java.util.Random;

/**
 * 
 * @author Alex
 *
 */
public class Arctic {
	private String name;
	private double swimDuration;
	private double heatRetentionFactor;
	private String speak;

	/**
	 * 
	 */
	public Arctic() {

	}

	/**
	 * 
	 * @param swimDuration
	 * @param heatRetentionFactor
	 * @param speak
	 */
	public Arctic(String name, double swimDuration, double heatRetentionFactor, String speak) {
		this.setName(name);
		this.setSwimDuration(swimDuration);
		this.setHeatRetentionFactor(heatRetentionFactor);
		this.setSpeak(speak);
	}

	/**
	 * 
	 */
	public boolean equals(Object obj) {
		Arctic equal = (Arctic) obj;
		return (this.heatRetentionFactor == equal.heatRetentionFactor && this.swimDuration == equal.swimDuration
				&& this.speak == equal.speak);
	}

	/**
	 * Generates either 0 or 1
	 * 
	 * @return the number generated
	 */
	private int numberGen() {
		Random gen = new Random();
		return gen.nextInt(2);
	}

	/**
	 * 
	 * @param Jungle
	 *            object to fight Arctic
	 */
	public void fight(Jungle fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Ocean
	 *            object to fight Arctic
	 */
	public void fight(Ocean fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Safari
	 *            object to fight Arctic
	 */
	public void fight(Safari fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @param Arctic
	 *            object to fight Arctic
	 */
	public void fight(Arctic fighting) {
		if (numberGen() == 1) {
			System.out.println(fighting.getName() + " wins");
		} else
			System.out.println(this.getName() + " wins");
	}

	/**
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		if (name == null) {
			throw new IllegalArgumentException("Name cannot be null");
		}
		this.name = name;
	}

	/**
	 * @return the speak
	 */
	public String getSpeak() {
		return speak;
	}

	/**
	 * @param speak
	 *            the speak to set
	 */
	public void setSpeak(String speak) {
		if (speak == null) {
			throw new IllegalArgumentException("Speak cannot be null");
		}
		this.speak = speak;
	}

	/**
	 * @return the swimDuration
	 */
	public double getSwimDuration() {
		return swimDuration;
	}

	/**
	 * @param swimDuration
	 *            the swimDuration to set
	 */
	public void setSwimDuration(double swimDuration) {
		if (swimDuration < 0) {
			throw new IllegalArgumentException("Swim duration cannot be less than zero");
		}
		this.swimDuration = swimDuration;
	}

	/**
	 * @return the heatRetentionFactor
	 */
	public double getHeatRetentionFactor() {
		return heatRetentionFactor;
	}

	/**
	 * @param heatRetentionFactor
	 *            the heatRetentionFactor to set
	 */
	public void setHeatRetentionFactor(double heatRetentionFactor) {
		if (heatRetentionFactor < 0) {
			throw new IllegalArgumentException("Heat retention factor cannot be less than zero");
		}
		this.heatRetentionFactor = heatRetentionFactor;
	}

}
