package com.hoglezoo.animals;

/**
 * 
 * @author Alex ways to travel in water
 */
public enum ModeOfTravelInWater {
	Fins, Propulsion, WaveRiding
}
