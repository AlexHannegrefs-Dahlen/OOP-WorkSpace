package store.grocery;

public interface GroceryInterface {

	double getWeight();

	void setWeight(double Weight);

	double getPrice();

	void setPrice(double priceLBS);

}
