package com.neumont.csc150.airplace;

/**
 * 
 * @author Alex
 *
 */
public enum Rank {
	SeniorCap,
	Cap,
	CoPilot
}
