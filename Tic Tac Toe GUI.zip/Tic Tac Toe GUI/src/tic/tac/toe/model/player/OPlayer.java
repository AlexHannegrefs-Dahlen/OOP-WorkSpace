package tic.tac.toe.model.player;

/**
 * 
 * @author Alex
 * 
 */
public class OPlayer extends Player {
	/**
	 * 
	 * @param turn
	 */
	public OPlayer(boolean turn) {
		super(turn);
	}

}
