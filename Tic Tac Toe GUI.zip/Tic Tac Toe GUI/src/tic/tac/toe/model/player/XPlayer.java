package tic.tac.toe.model.player;

/**
 * 
 * @author Alex
 *
 */
public class XPlayer extends Player {
	/**
	 * 
	 * @param turn
	 */
	public XPlayer(boolean turn) {
		super(turn);
	}

}
